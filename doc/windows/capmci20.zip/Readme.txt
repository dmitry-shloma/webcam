Basic Video capture and play
============================

Freeware
version 2.0 - Sep 30, 1998
Copyright (c) 1998, Wolfgang Krug

----------------------------------------------------------------------------

CONTENTS
========

1. Target platforms
2. Description
3. Installation
4. Read this
5. Known bugs & problems
6. More informations
7. Contact

----------------------------------------------------------------------------

1. Target platforms
===================

Delphi 2.0
Delphi 3.0
Delphi 4.0


2. Description
==============

This program shows how to capture and replay video
using the cap_ and mci_ functions of the 
video for windows SDK.
Uses avifil32.dll and avicap32.dll


3. Installation
===============

Nothing to install. Compile and run the program.


4. Read this
============

WARNING! THE CODE IS PROVIDED AS IS WITH NO GUARANTEES OF ANY KIND!
USE THIS AT YOUR OWN RISK - YOU ARE THE ONLY PERSON RESPONSIBLE FOR
ANY DAMAGE THIS CODE MAY CAUSE - YOU HAVE BEEN WARNED!


5. Known bugs & problems
========================

Nothing up to now!


6. More informations
====================

This component is FREEWARE. 


7. Contact
===========

E-mail:     krug@sdm.de


                        -------------------------
                          --------------------
