VCL component to capture video and single bitmaps.
Reqiures DirectShow.
Version 1.15

(c) Egor Averchenkov (e_g_o_r@mail.ru), 2001-2002
Latest revision: November 03, 2002.


About.
------------------------

  TVideoCapture - Delphi wrapper for DirectShow video capture functions.

  Code is based on
  Microsoft's AMCap & StillCap samples from DirectX SDK
    and
  DScapture by orthkon * www.mp3.com/orthkon * orthkon@mail.com

  Compatible with D5, D6 and BCB5.
  Tested under Win98 & Win2k & DX8.1 with miniDV camcoder,
  Genius VideoCAM III, bt878 WDM TVTuner.
  DX8 or later is required to capture bitmaps.

  I use this component in my software to capture bitmaps
  (and sometimes video) from Sony miniDV camcoder and webcams.

  !!! To compile demo you must have RxLib. Don't ask me where to get it !!!

  Sorry, I'm rather lazy to write anything else about. (o:
  If you have questions - e-mail me.


License Agreement
------------------------

  Permission to use, copy, modify, and distribute this software and its
  documentation for any purpose and without fee is hereby granted,
  provided that the above copyright notice appears in all copies and
  that both the above copyright notice and this permission notice appear
  in supporting documentation, and that the name the author
  not be used in advertising or publicity pertaining to distribution of
  the software without specific, written prior permission. This
  software is made available "as is", and AUTHOR DISCLAIM
  ALL WARRANTIES, EXPRESS OR IMPLIED, WITH REGARD TO THIS SOFTWARE,
  INCLUDING WITHOUT LIMITATION ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS FOR A PARTICULAR PURPOSE, AND IN NO EVENT SHALL AUTHORS BE
  LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY
  DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
  WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING NEGLIGENCE) OR
  STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.

  In other words - feel free to use this code)))
  I hope someone find it usefull. If you do - send me a message, pls.
  (Beer messages would be appreciated a lot!!! :o) )


History log.
------------------------

  01-04-24 - v1.00 (initial release)

  01-09-18 - v1.02 -  I had to continue this work after a long delay
    some stupid bugs corrected
    interface section was slightly ordered
    new property CapturePixelFormat added to select color depth of captured bitmaps

  01-09-20 - v1.03 - orthkon mailed me TCapture based on this component - good work!
    added properties and functions to work with available capture modes

  01-09-22 - v1.04
    working with filters property pages

  01-10-18 - v1.05
    working with compressors

  01-10-27 - v1.06 - thanks to Lee_Nover (Lee.Nover@email.si) - he did all dirty work))))
    one graph for preview/capture
    compression dialogs

  01-10-28 - v1.07
    bugs in building graph with compressors were corrected

  01-11-23 - v1.08
    completely rewriten graph building/controlling functions
    new properties:
        IsDV - Indicates DV Capture source is used
        WantDVAudio - Force using DV Audio stream to capture audio
                      when DV device is used for capturing

    Sorry but I've changed some names(((

  01-11-25 - v1.09
    saving/restoring capture graph configuration

  02-05-25 - v1.10
    some bugs corrected
    graph restoring/building algorithms slightly ordered
    new properties:
      VCompDevice - name of video compressor used
      ACompDevice - name of audio compressor used
      VCapDevice  - name of video capture device used
      ACapDevice  - name of audio capture device used
      VCapIndex   - index of video capture device used
      ACapIndex   - index of audio capture device used
      VCompIndex  - index of video compressor device used
      ACompIndex  - index of audio compressor device used
      ACapModeIdx - index of audio capture mode used
      VCapModeIdx - index of video capture mode used

  02-10-10 - v1.11
    1. added SampleGrabber buffer locking functions
       to avoid simultaneous access from different threads
    2. added OnFramePassed event firing every time frame comes
       through SampleGrabber

  02-10-13 - v1.12
    only BCB support added to sources
    Packages for D5, D6 & BCB5 added

  02-10-16 - v1.13
    added WantAudioPreview property to disable audio preview rendering
    added OnAborted event to indicate graph run aborted for some reason
    added OnDeviceLost event to indicate capture device lost during preview/capture
    some optimization done

  02-10-20 - v1.14
    some bugs in working with the capture and compressor lists corrected

  02-11-03 - v1.15
    bugs when working with DV capture devices corrected
    bug in rendering graph with WantAudioPreview property corrected
    bug in working with the capture and compressor lists corrected

Known problems.
------------------------

  Some audio compressor filters do not expose IAMStreamControl
  (it's pitty but ACM Wrapper does not((( ) so component can't correctly
  start/stop capture part of graph using such filters.
  It's recomended to use native DShow audio compressors to capture avi.


Egor Averchenkov, e_g_o_r@mail.ru
November, 2002.
